<?php
class mxCalendarSettings extends xPDOSimpleObject {}