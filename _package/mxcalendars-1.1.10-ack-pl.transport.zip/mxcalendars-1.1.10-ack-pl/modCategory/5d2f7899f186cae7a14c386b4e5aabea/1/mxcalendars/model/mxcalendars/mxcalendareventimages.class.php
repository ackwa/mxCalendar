<?php
class mxCalendarEventImages extends xPDOSimpleObject {}