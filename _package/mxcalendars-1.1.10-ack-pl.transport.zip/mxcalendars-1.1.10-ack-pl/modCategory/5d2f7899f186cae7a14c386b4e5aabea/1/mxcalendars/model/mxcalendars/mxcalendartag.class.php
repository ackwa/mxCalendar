<?php
class mxCalendarTag extends xPDOSimpleObject {}