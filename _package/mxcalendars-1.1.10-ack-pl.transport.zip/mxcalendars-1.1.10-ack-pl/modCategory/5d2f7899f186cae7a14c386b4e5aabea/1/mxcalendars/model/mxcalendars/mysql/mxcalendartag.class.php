<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendartag.class.php');
class mxCalendarTag_mysql extends mxCalendarTag {}