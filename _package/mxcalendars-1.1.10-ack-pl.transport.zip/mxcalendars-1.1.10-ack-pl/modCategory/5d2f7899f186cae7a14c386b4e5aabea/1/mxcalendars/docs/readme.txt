
This extra is intended to be used to manage events via single ModX management interface. Provide multiple display options and allow full customization of the UI. Additional features will be added in the second quarter of 2012.

Learn more at <a href="http://charlesmx.com/software/mxcalendar-revo.html?refpkmx">CharlesMx.com mxCalendar Revo</a>