<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendareventwug.class.php');
class mxCalendarEventWUG_mysql extends mxCalendarEventWUG {}