<?php
class mxCalendarEventVideos extends xPDOSimpleObject {}