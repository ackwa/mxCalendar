<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendareventtags.class.php');
class mxCalendarEventTags_mysql extends mxCalendarEventTags {}