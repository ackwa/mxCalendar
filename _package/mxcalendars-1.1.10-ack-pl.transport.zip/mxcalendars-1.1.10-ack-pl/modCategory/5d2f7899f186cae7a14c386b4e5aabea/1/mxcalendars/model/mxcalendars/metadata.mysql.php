<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'mxCalendarEvents',
    1 => 'mxCalendarEventImages',
    2 => 'mxCalendarEventVideos',
    3 => 'mxCalendarEventWUG',
    4 => 'mxCalendarCategories',
    5 => 'mxCalendarCalendars',
    6 => 'mxCalendarSettings',
    7 => 'mxCalendarFeed',
    8 => 'mxCalendarLog',
    9 => 'mxCalendarTag',
  ),
  'xPDOObject' => 
  array (
    0 => 'mxCalendarEventTags',
  ),
);