<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendarfeed.class.php');
class mxCalendarFeed_mysql extends mxCalendarFeed {}