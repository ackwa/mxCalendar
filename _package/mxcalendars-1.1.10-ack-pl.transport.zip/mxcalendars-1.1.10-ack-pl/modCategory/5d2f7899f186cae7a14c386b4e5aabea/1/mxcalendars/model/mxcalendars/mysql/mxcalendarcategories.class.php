<?php
require_once (dirname(dirname(__FILE__)) . '/mxcalendarcategories.class.php');
class mxCalendarCategories_mysql extends mxCalendarCategories {}