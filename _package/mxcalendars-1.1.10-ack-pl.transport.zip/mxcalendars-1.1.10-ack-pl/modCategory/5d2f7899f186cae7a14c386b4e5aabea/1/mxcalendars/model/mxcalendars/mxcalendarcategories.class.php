<?php
class mxCalendarCategories extends xPDOSimpleObject {}