<?php
class mxCalendarEventTags extends xPDOObject {}